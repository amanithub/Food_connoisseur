from django.contrib import admin
from home.models import File_upload
# Register your models here.
admin.site.register(File_upload)